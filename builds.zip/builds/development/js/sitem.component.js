System.register(['angular/core'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var core_1;
    var SitemComponent;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            }],
        execute: function() {
            core_1.Component({
                selector: 'selected-item',
                template: '<p>hai{{sitem.productName}}<p>',
                inputs: ['sitem']
            });
            SitemComponent = (function () {
                function SitemComponent() {
                }
                return SitemComponent;
            }());
            exports_1("SitemComponent", SitemComponent);
        }
    }
});

//# sourceMappingURL=sitem.component.js.map
