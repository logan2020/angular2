export interface Product
{
    productName:"String";
    imageUrl:"String";
    description:"String";
}
