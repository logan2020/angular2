import {Component} from 'angular2/core';

import {Product} from './product';

@Component({
    selector:'my-app',
    templateUrl:'partials/availableItems.html'
})

export class AppComponent{
    name:String;
    selecteditem:Product;
    name="Anusuya";
    query="css";
    listOfProducts=shoppingList;
    constructor()
    {
        console.log(shoppingList);
    };
    itemname(item)
    {
        this.selecteditem=item;
        console.log(this.selecteditem);
    }
}

var shoppingList:Product[]=[{productName:"MI MAX",imageUrl:"mi",description:"Barot has just finished his final year at The Royal Academy of Painting and Sculpture, where he excelled in glass etching paintings and portraiture. Hailed as one of the most diverse artists of his generation, Barot is equally as skilled with watercolors as he is with oils, and is just as well-balanced in different subject areas. Barot's collection entitled \"The Un-Collection\" will adorn the walls of Gilbert Hall, depicting his range of skills and sensibilities - all of them, uniquely Barot, yet undeniably different"},
{productName:"MICROMAX A102",imageUrl:"micromaxa102",description:"The Artist to Watch in 2012 by the London Review, Johnathan has already sold one of the highest priced-commissions paid to an art student, ever on record. The piece, entitled Gratitude Resort, a work in oil and mixed media, was sold for $750,000 and Jonathan donated all the proceeds to Art for Peace, an organization that provides college art scholarships for creative children in developing nations"},
{productName:"SAMSUNG CHINA",imageUrl:"samsungchina",description:"Hillary is a sophomore art sculpture student at New York University, and has already won all the major international prizes for new sculptors, including the Divinity Circle, the International Sculptor's Medal, and the Academy of Paris Award. Hillary's CAC exhibit features 25 abstract watercolor paintings that contain only water images including waves, deep sea, and river."},
{productName:"G-FIVE",imageUrl:"gfive",description:"The Art College in New Dehli has sponsored Hassum on scholarship for his entire undergraduate career at the university, seeing great promise in his contemporary paintings of landscapes - that use equal parts muted and vibrant tones, and are almost a contradiction in art. Hassum will be speaking on \"The use and absence of color in modern art\" during Thursday's agenda."}];
