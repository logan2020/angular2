import {Component} from 'angular2/core';

@Component({
    selector:'selected-item',
    template:`
            <h1>{{item.productName}}</h1>
            <p>{{item.description}}</p>
            `,
    inputs:['item']
})

export class SitemComponent
{

}
