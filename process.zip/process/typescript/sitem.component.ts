import {Component} from 'angular/core';

Component({
    selector:'selected-item',
    template:'<p>hai{{sitem.productName}}<p>',
    inputs:['sitem']

})

export class SitemComponent
{

}
