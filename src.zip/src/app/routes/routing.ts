import {Routes} from '@angular/router';
import {RouterModule} from '@angular/router';

import { homeComponent }  from '../homecomponent/homeComponent';
import { buyNowComponent }  from '../buynowcomponent/buyNowComponent';

const appRoutes:Routes =[
						{path:'home',component:homeComponent},
						{path:'buyNow',component:buyNowComponent},
						{path:'',pathMatch:'full',redirectTo:'home'} ];
						
export const routing=RouterModule.forRoot(appRoutes);