"use strict";
var router_1 = require('@angular/router');
var homeComponent_1 = require('../homecomponent/homeComponent');
var buyNowComponent_1 = require('../buynowcomponent/buyNowComponent');
var appRoutes = [
    { path: 'home', component: homeComponent_1.homeComponent },
    { path: 'buyNow', component: buyNowComponent_1.buyNowComponent },
    { path: '', pathMatch: 'full', redirectTo: 'home' }];
exports.routing = router_1.RouterModule.forRoot(appRoutes);
//# sourceMappingURL=routing.js.map