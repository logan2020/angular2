import { Component } from '@angular/core';
import { Http } from '@angular/http';

@Component({
  selector: 'home-component',
  templateUrl:'../app/homecomponent/home.html',
  styleUrls:['../app/css/bootstrap.min.css','../app/homecomponent/user.css']
})
export class homeComponent  { 
	res:any;
	
	constructor(private http:Http){
	}
	ngOnInit(){
			this.http.get('../app/data/home.json').subscribe(response=>{
			this.res=response.json();
		});
	}
}    