import {Component} from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';

import { employeeListService } from '../data/employeeListService';


@Component({
  selector: 'app',
  templateUrl: './app.component.html',
  styleUrls:['app.component.css']
})
export class AppComponent {
	
	constructor(private table:employeeListService){}

	registerForm = new FormGroup({
    name: new FormControl(),
    id: new FormControl(),
    location: new FormControl(),
    doj: new FormControl(),
    projectName: new FormControl()
    
	});
  
	submit(formvalue)
	{
		console.log(formvalue);
		this.table.add(formvalue);
	}
}
