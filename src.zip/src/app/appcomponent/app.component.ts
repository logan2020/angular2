import { Component } from '@angular/core';

@Component({
  selector: 'my-app',
  template:`
			<home-component></home-component>
			<sub-app></sub-app>`,
  styleUrls:['../app/css/bootstrap.min.css']
})
export class AppComponent{ 
	
	
}    