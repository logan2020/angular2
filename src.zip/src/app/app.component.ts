import { Component } from '@angular/core';

@Component({
  selector: 'my-app',
  templateUrl:'/app/appcomponent/homepage.html',
  styleUrls:['../app/css/bootstrap.min.css','../app/appcomponent/user.css']
})
export class AppComponent  {  }    
