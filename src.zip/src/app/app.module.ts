import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import {HttpModule} from '@angular/http';
import { CarouselModule } from 'ng2-bootstrap';
//import { Ng2BootstrapModule } from 'ng2-bootstrap';

import { AppComponent }  from './appcomponent/app.component';
import { buyNowComponent }  from './buynowcomponent/buyNowComponent'; 
import { homeComponent }  from './homecomponent/homeComponent';
import {routing} from '../app/routes/routing';

//import { ConfirmationComponent }  from './confirmationcomponent/ConfirmationComponent';
//import{routing} from'./app/app.routing';

@NgModule({
  imports:      [ CarouselModule.forRoot(),routing,BrowserModule,HttpModule],
  declarations: [ AppComponent, buyNowComponent,homeComponent],
  bootstrap:    [ AppComponent ]
})
export class AppModule { }
