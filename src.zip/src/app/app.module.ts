import { NgModule } from '@angular/core'
import { BrowserModule } from '@angular/platform-browser';
import { ReactiveFormsModule } from '@angular/forms';

import { AppComponent } from './appComponent/app.component';
import { employeeListComponent } from './employeeListComponent/employeeListComponent';
import { employeeListService } from './data/employeeListService';

@NgModule({
  declarations: [
    AppComponent,
	employeeListComponent
  ],
  imports: [
    BrowserModule,
    ReactiveFormsModule	
  ],
  providers: [
	employeeListService
  ],
  bootstrap: [ AppComponent ]
})
export class AppModule {

}
