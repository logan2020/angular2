import {Component} from '@angular/core';

@Component({
	selector:'sub-app',
	templateUrl:'../app/buynowcomponent/Buy_Now.html',
	styleUrls:['../app/css/bootstrap.min.css','../app/buynowcomponent/Buy_Now.css']
})

export class buyNowComponent{
}