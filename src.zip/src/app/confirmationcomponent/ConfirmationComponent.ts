import {Component} from '@angular/core';

@Component({
	selector:'',
	templateUrl:'../app/confirmationpage.html',
	styleUrls:['../app/css/bootstrap.min.css','../app/appcomponent/confirmationpage.css']
})

export class buyNowComponent{
}