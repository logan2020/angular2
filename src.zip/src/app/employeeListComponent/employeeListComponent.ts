import {Component} from '@angular/core';

import { employeeListService } from '../data/employeeListService';

@Component({
	selector:'employee-list',
	templateUrl:'./employeeListPartial.html',
	styleUrls:['employeeListPartial.css']
})

export class employeeListComponent{
	employeeList:any;			
	constructor(private empservice:employeeListService)
	{
		this.employeeList=empservice.get();
	}
	
}