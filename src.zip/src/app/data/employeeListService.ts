export class employeeListService
{
	employeeList=[
				{name:'vijay',id:'1263098',location:'chennai',doj:'25-03-2016',projectName:'citi'},
				{name:'raja',id:'1260008',location:'bangalore',doj:'28-02-2016',projectName:'BOA'},
				{name:'chithra',id:'1259661',location:'chennai',doj:'01-03-2016',projectName:'HYNDAI'}
				];
	
	get()
	{
		return this.employeeList;
	}
	add(employee)
	{
	  this.employeeList.push(employee);
	}
}