var express = require('express');
var bodyParser = require('body-parser');
var fs=require('fs');
var f='data/write.txt';
// create our app
var app = express();

app.use(bodyParser());

 app.get('/', function(req, res){
  res.sendfile('index.html');
 });

app.post('/', function(req, res){
  var userName = req.body.userName;
  var password = req.body.password;
  var html = 'Hello: ' + userName + '.<br>' +
             '<a href="/">Try again.</a>';
  var obj="{ \n userName:"+userName+",\npassword:"+password+"\n}"
  fs.appendFile(f,obj,function(err){
    if(err)
      console.error(err);
    console.log('Written!');
  });
  res.send(html);
});

app.listen(3000)