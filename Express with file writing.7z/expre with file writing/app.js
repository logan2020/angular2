var express = require('express');
var bodyParser = require('body-parser');
var fs=require('fs');
var f='data/write.txt';
// create our app
var app = express();

// instruct the app to use the `bodyParser()` middleware for all routes
app.use(bodyParser());

 app.get('/', function(req, res){
//   // The form's action is '/' and its method is 'POST',
//   // so the `app.post('/', ...` route will receive the
//   // result of our form
//   var html = '<form action="/" method="post">' +
//                'Enter your name:' +
//                '<input type="text" name="userName" placeholder="..." />' +
//                '<br>' +
//                '<button type="submit">Submit</button>' +
//             '</form>';
               
//   res.send(html);
  res.sendfile('index.html');
 });

// This route receives the posted form.
// As explained above, usage of 'body-parser' means
// that `req.body` will be filled in with the form elements
app.post('/', function(req, res){
  var userName = req.body.userName;
  var password = req.body.password;
  var html = 'Hello: ' + userName + '.<br>' +
             '<a href="/">Try again.</a>';
  var obj="{ \n userName:"+userName+",\npassword:"+password+"\n}"
  fs.appendFile(f,obj,function(err){
    if(err)
      console.error(err);
    console.log('Written!');
  });
  res.send(html);
});

app.listen(3000)